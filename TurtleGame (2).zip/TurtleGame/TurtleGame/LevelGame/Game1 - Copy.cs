﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO;
using LevelGame.NewFolder1;
using LevelGame.NewFolder2;
/*
namespace LevelGame
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {

        Texture2D bg_image;

        enum Menu
        {
            playing,
            pause,
            options,
            start
        }

        Menu currentState = Menu.playing;

        GraphicsDeviceManager graphics;
      
        SpriteBatch spriteBatch;
        ScreenManager screenManager;


        static readonly string[] preloadAssets =
      {
            "gradient",
        };


        Texture2D blockTexture1;
        Texture2D blockTexture2;
        Texture2D blockTexture3;
        Texture2D finishTexture;
        Texture2D item;
        List<Item> items;
        List<Spike> spike;



        Texture2D idleTexture;
        Texture2D runTexture;
        Texture2D jumpTexture;

        
        AnimatedSprite hero;
        Vector2 heroPosition;
        bool personHit = false;

        public int Width;
        public int Height;

       
        List<Block> blocks;
    

        static int ScrollX;
        int levelLength;
        int blcSize = 50;

        int currentLevel= 3;

        /// <summary>
      
        /// </summary>
        KeyboardState oldState;
        
        
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            Width = graphics.PreferredBackBufferWidth = 800;
            Height = graphics.PreferredBackBufferHeight = 10 * blcSize;


            // Create the screen manager component.
            screenManager = new ScreenManager(this);

            Components.Add(screenManager);

            // Activate the first screens.
            screenManager.AddScreen(new BackgroundScreen(), null);
            screenManager.AddScreen(new MainMenuScreen(), null);
        



    }
       

     //rect is player i think
        public bool CollidesWithLevel(Rectangle rect)
        {
            foreach (Block block in blocks)
            {
                if (block.rect.Intersects(rect))
                    return true;
            }
            return false;
        }
        public bool CollidesWithEnd(Rectangle rect)
        {
            foreach (Item block in items)
            {
                if (block.rect.Intersects(rect))
                {
                    hero.rect = new Rectangle(0, Height - idleTexture.Height - 40, 60, 60);
                    hero.Stop();
                    currentLevel++;
                    CreateLevel();
                    return true;
                }
            }
            return false;
        }
        public bool CollidesWithSpike(Rectangle rect)
        {
            foreach (Spike block in spike)
            {
                if (block.rect.Intersects(rect))
                {
                  hero.rect = new Rectangle(0, Height - idleTexture.Height - 40, 60, 60);
                    hero.Stop();
                    
                    CreateLevel();
                    return true;
                }
            }
            return false;
        }

        public void reset()
        {
            if (CollidesWithSpike(hero.rect) == true) {
                hero.Stop();
            }
        }

        public static Rectangle GetScreenRect(Rectangle rect)
        {
      
            rect.Offset(-ScrollX, 0);
            return rect;
        }
        public void Scroll(int dx)
        {
            if (ScrollX + dx >= 0 && ScrollX + dx <= levelLength - Height)
                ScrollX += dx;
        }
        public void CreateLevel()
        {
            
            if (currentLevel > 3)
                currentLevel = 1;
            blocks = new List<Block>();
            string[] s = File.ReadAllLines("content/levels/level" + currentLevel + ".txt");

            levelLength = blcSize * s[0].Length - 400;
            int x = 0;
            int y = 0;
            foreach (string str in s)
            {
                foreach (char c in str)
                {
                    Rectangle rect = new Rectangle(x, y, blcSize, blcSize);
                    if (c == 'X')
                    {
                        
                        Block block = new Block(rect, blockTexture2);
                        blocks.Add(block);
                    }
                    if (c == 'Y')
                    {
                        Block block = new Block(rect, blockTexture1);
                        blocks.Add(block);
                    }
                    if (c == 'Z')
                    {
                        Block block = new Block(rect, blockTexture3);
                        blocks.Add(block);
                    }
                    x += blcSize;
                }
                x = 0;
                y += blcSize;
            }
            items = new List<Item>();
            string[] s1 = File.ReadAllLines("content/levels/level" + currentLevel + ".txt");

            x = 0;
            y = 0;
            foreach (string str in s)
            {
                foreach (char c in str)
                {
                    Rectangle rect = new Rectangle(x, y, blcSize, blcSize);
                    if (c == 'F')
                    {
                        Item graal = new Item(rect, finishTexture);
                        items.Add(graal);
                    }
                    x += blcSize;
                }
                x = 0;
                y += blcSize;
            }
            spike = new List<Spike>();
            string[] sp = File.ReadAllLines("content/levels/level" + currentLevel + ".txt");

            x = 0;
            y = 0;
            foreach (string str in s)
            {
                foreach (char c in str)
                {
                    Rectangle rect = new Rectangle(x, y, blcSize, blcSize);
                    if (c == 'S')
                    {
                        Spike gra = new Spike(rect, item);
                        spike.Add(gra);
                    }
                    x += blcSize;
                }
                x = 0;
                y += blcSize;
            }





        }
        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);

            blockTexture1 = Content.Load<Texture2D>("Textures/jc");
            blockTexture2 = Content.Load<Texture2D>("Textures/jb");
            blockTexture3 = Content.Load<Texture2D>("Textures/ja");

            idleTexture = Content.Load<Texture2D>("Textures/sheetidle");
            runTexture = Content.Load<Texture2D>("Textures/sheetrun");
            jumpTexture = Content.Load<Texture2D>("Textures/sheetjump");

            bg_image = Content.Load<Texture2D>("Textures/jj");
            finishTexture = Content.Load<Texture2D>("Textures/sheetgirl");
            item = Content.Load<Texture2D>("Textures/jd");
            CreateLevel();
            // bg_image = Content.Load<Texture2D>("Textures/bg");

            Rectangle rect = new Rectangle(0, Height - idleTexture.Height - 40, 60, 60);
            hero = new AnimatedSprite(rect, idleTexture, runTexture, jumpTexture, this);

            foreach (string asset in preloadAssets)
            {
                Content.Load<object>(asset);
            }
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            // TODO: Add your update logic here
            KeyboardState keyState = Keyboard.GetState();

            if (keyState.IsKeyDown(Keys.K) && oldState.IsKeyUp(Keys.K))
                currentLevel++;
                CreateLevel();


            if (keyState.IsKeyDown(Keys.Space))
                hero.go();
          

            if (keyState.IsKeyDown(Keys.Up))
                hero.Jump();

            Rectangle heroScreenRect = GetScreenRect(hero.rect);

            if (heroScreenRect.Left < Width / 2)
                Scroll(-3*gameTime.ElapsedGameTime.Milliseconds/10);
            if (heroScreenRect.Left > Width / 2)
                Scroll(3 * gameTime.ElapsedGameTime.Milliseconds / 10);

            oldState = keyState;

            hero.Update(gameTime);

            CollidesWithSpike(hero.rect);
            CollidesWithEnd(hero.rect);
     


            base.Update(gameTime);
        }

     

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
          
           spriteBatch.Draw(bg_image, Vector2.Zero, new Rectangle(0, 0, 800, 600), Color.White);
          //  spriteBatch.Draw(bg_image, Vector2.Zero, new Rectangle(0, 0, 0, 0), Color.White, 0, Vector2.Zero, 2.0f, SpriteEffects.None, 0);
          //  spriteBatch.Draw(bg_image, Vector2.Zero,  Color.White);
            foreach (Block block in blocks)
            {
                block.Draw(spriteBatch);
            }
            foreach (Item item in items)
            {
                item.Draw(spriteBatch);
            }
            foreach (Spike spike in spike)
            {
                spike.Draw(spriteBatch);
            }
            spriteBatch.End();

           
            hero.Draw(spriteBatch);

            base.Draw(gameTime);
        }
    }
}
*/